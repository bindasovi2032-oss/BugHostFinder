package com.example.data

object CountryCatalog {
    val presets: List<CountryPreset> = listOf(
        CountryPreset(
            name = "Worldwide Top CDNs",
            code = "GL",
            flag = "🌐",
            region = "Global",
            hosts = listOf(
                "cloudflare.com",
                "fastly.com",
                "akamai.com",
                "aws.amazon.com",
                "google.com",
                "microsoft.com",
                "jsdelivr.net",
                "cdnjs.cloudflare.com",
                "unpkg.com",
                "github.com"
            )
        ),
        CountryPreset(
            name = "United States",
            code = "US",
            flag = "🇺🇸",
            region = "North America",
            hosts = listOf(
                "cloudflare.com",
                "google.com",
                "apple.com",
                "netflix.com",
                "amazon.com",
                "github.com",
                "wikipedia.org",
                "reddit.com",
                "yahoo.com",
                "speedtest.net"
            )
        ),
        CountryPreset(
            name = "Indonesia",
            code = "ID",
            flag = "🇮🇩",
            region = "Asia",
            hosts = listOf(
                "telkomsel.com",
                "indosatooredoo.com",
                "xl.co.id",
                "tokopedia.com",
                "shopee.co.id",
                "bukalapak.com",
                "detik.com",
                "kompas.com",
                "kemdikbud.go.id",
                "gojek.com"
            )
        ),
        CountryPreset(
            name = "Philippines",
            code = "PH",
            flag = "🇵🇭",
            region = "Asia",
            hosts = listOf(
                "globe.com.ph",
                "smart.com.ph",
                "pldt.com",
                "gcash.com",
                "maya.ph",
                "lazada.com.ph",
                "shopee.ph",
                "inquirer.net",
                "gmanetwork.com",
                "abs-cbn.com"
            )
        ),
        CountryPreset(
            name = "India",
            code = "IN",
            flag = "🇮🇳",
            region = "Asia",
            hosts = listOf(
                "jio.com",
                "airtel.in",
                "vodafoneidea.com",
                "flipkart.com",
                "hotstar.com",
                "paytm.com",
                "ndtv.com",
                "timesofindia.indiatimes.com",
                "irctc.co.in",
                "uidai.gov.in"
            )
        ),
        CountryPreset(
            name = "Brazil",
            code = "BR",
            flag = "🇧🇷",
            region = "South America",
            hosts = listOf(
                "claro.com.br",
                "vivo.com.br",
                "tim.com.br",
                "globo.com",
                "uol.com.br",
                "mercadolivre.com.br",
                "magazineluiza.com.br",
                "gov.br",
                "itau.com.br",
                "nubank.com.br"
            )
        ),
        CountryPreset(
            name = "United Kingdom",
            code = "GB",
            flag = "🇬🇧",
            region = "Europe",
            hosts = listOf(
                "bbc.co.uk",
                "gov.uk",
                "theguardian.com",
                "bt.com",
                "vodafone.co.uk",
                "ee.co.uk",
                "o2.co.uk",
                "sky.com",
                "virginmedia.com",
                "dailymail.co.uk"
            )
        ),
        CountryPreset(
            name = "Germany",
            code = "DE",
            flag = "🇩🇪",
            region = "Europe",
            hosts = listOf(
                "telekom.de",
                "vodafone.de",
                "o2online.de",
                "spiegel.de",
                "tagesschau.de",
                "bild.de",
                "heise.de",
                "gmx.net",
                "web.de",
                "bahn.de"
            )
        ),
        CountryPreset(
            name = "South Africa",
            code = "ZA",
            flag = "🇿🇦",
            region = "Africa",
            hosts = listOf(
                "vodacom.co.za",
                "mtn.co.za",
                "telkom.co.za",
                "cellc.co.za",
                "news24.com",
                "takealot.com",
                "gov.za",
                "standardbank.co.za",
                "fnb.co.za",
                "iol.co.za"
            )
        ),
        CountryPreset(
            name = "Nigeria",
            code = "NG",
            flag = "🇳🇬",
            region = "Africa",
            hosts = listOf(
                "mtn.ng",
                "airtel.com.ng",
                "glo.com",
                "9mobile.com.ng",
                "jumia.com.ng",
                "konga.com",
                "punchng.com",
                "vanguardngr.com",
                "gtbank.com",
                "flutterwave.com"
            )
        ),
        CountryPreset(
            name = "Singapore",
            code = "SG",
            flag = "🇸🇬",
            region = "Asia",
            hosts = listOf(
                "singtel.com",
                "starhub.com",
                "m1.com.sg",
                "straitstimes.com",
                "cna.asia",
                "gov.sg",
                "dbs.com.sg",
                "grab.com",
                "shopee.sg",
                "lazada.sg"
            )
        ),
        CountryPreset(
            name = "Japan",
            code = "JP",
            flag = "🇯🇵",
            region = "Asia",
            hosts = listOf(
                "docomo.ne.jp",
                "au.com",
                "softbank.jp",
                "rakuten.co.jp",
                "yahoo.co.jp",
                "nhk.or.jp",
                "asahi.com",
                "yodobashi.com",
                "line.me",
                "linecorp.com"
            )
        ),
        CountryPreset(
            name = "Australia",
            code = "AU",
            flag = "🇦🇺",
            region = "Oceania",
            hosts = listOf(
                "telstra.com.au",
                "optus.com.au",
                "vodafone.com.au",
                "abc.net.au",
                "news.com.au",
                "smh.com.au",
                "gov.au",
                "commbank.com.au",
                "woolworths.com.au",
                "atlassian.com"
            )
        ),
        CountryPreset(
            name = "United Arab Emirates",
            code = "AE",
            flag = "🇦🇪",
            region = "Middle East",
            hosts = listOf(
                "etisalat.ae",
                "du.ae",
                "gulfnews.com",
                "khaleejtimes.com",
                "emirates.com",
                "noon.com",
                "amazon.ae",
                "government.ae",
                "enbd.com",
                "careem.com"
            )
        ),
        CountryPreset(
            name = "Mexico",
            code = "MX",
            flag = "🇲🇽",
            region = "North America",
            hosts = listOf(
                "telcel.com",
                "att.com.mx",
                "movistar.com.mx",
                "eluniversal.com.mx",
                "mercadolibre.com.mx",
                "gob.mx",
                "bbva.mx",
                "banamex.com",
                "televisa.com",
                "liverpool.com.mx"
            )
        ),
        CountryPreset(
            name = "France",
            code = "FR",
            flag = "🇫🇷",
            region = "Europe",
            hosts = listOf(
                "orange.fr",
                "sfr.fr",
                "bouyguestelecom.fr",
                "free.fr",
                "lemonde.fr",
                "lefigaro.fr",
                "gouv.fr",
                "ovhcloud.com",
                "deezer.com",
                "sncf.com"
            )
        )
    )
}
