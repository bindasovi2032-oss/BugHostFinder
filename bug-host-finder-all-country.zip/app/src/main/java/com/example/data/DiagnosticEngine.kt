package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

class DiagnosticEngine {

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(8, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val noRedirectHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .followRedirects(false)
        .followSslRedirects(false)
        .build()

    suspend fun diagnoseHost(
        rawInput: String,
        port: Int = 443,
        method: String = "GET",
        followRedirects: Boolean = true
    ): HostDiagnosticResult = withContext(Dispatchers.IO) {
        val cleanHost = sanitizeHost(rawInput)
        val isHttps = port == 443 || rawInput.startsWith("https://", ignoreCase = true)
        val scheme = if (isHttps) "https" else "http"
        val portSuffix = if ((isHttps && port == 443) || (!isHttps && port == 80)) "" else ":$port"
        val targetUrl = "$scheme://$cleanHost$portSuffix/"

        // 1. Resolve DNS records
        val dnsRecords = runCatching {
            val addresses = InetAddress.getAllByName(cleanHost)
            addresses.map { it.hostAddress ?: "" }.filter { it.isNotEmpty() }
        }.getOrDefault(emptyList())

        val primaryIp = dnsRecords.firstOrNull()
        val reverseDns = primaryIp?.let {
            runCatching { InetAddress.getByName(it).canonicalHostName }.getOrNull()
        }

        // 2. Perform TCP Ping
        val tcpPing = pingTcpSocket(cleanHost, port, attempts = 3)

        // 3. SSL Certificate Info (if HTTPS)
        val sslInfo = if (isHttps) {
            fetchSslDetails(cleanHost, port)
        } else null

        // 4. HTTP / HTTPS Request
        val client = if (followRedirects) httpClient else noRedirectHttpClient
        val startTime = System.currentTimeMillis()
        var httpCode: Int? = null
        var httpMessage: String? = null
        var protocolName: String? = null
        var headersMap = mutableMapOf<String, String>()
        var serverHeader: String? = null
        var cdnDetected: String? = null
        var isSuccess = false
        var errorDetail: String? = null

        try {
            val requestBuilder = Request.Builder()
                .url(targetUrl)
                .header("User-Agent", "BugHostFinder-Diagnostic/1.0 (Android Network Diagnostics)")
                .header("Accept", "*/*")

            when (method.uppercase()) {
                "HEAD" -> requestBuilder.head()
                "OPTIONS" -> requestBuilder.method("OPTIONS", null)
                else -> requestBuilder.get()
            }

            val response = client.newCall(requestBuilder.build()).execute()
            response.use { resp ->
                httpCode = resp.code
                httpMessage = resp.message
                protocolName = resp.protocol.name
                serverHeader = resp.header("Server")

                resp.headers.forEach { pair ->
                    headersMap[pair.first] = pair.second
                }
                cdnDetected = detectCdn(headersMap, serverHeader, cleanHost)
                isSuccess = true
            }
        } catch (e: Exception) {
            errorDetail = e.message ?: e.localizedMessage ?: "Connection failed"
            // If HTTP request failed but TCP ping worked or DNS worked, we still report data
            if (dnsRecords.isNotEmpty()) {
                cdnDetected = detectCdn(emptyMap(), null, cleanHost)
            }
        }
        val responseTime = System.currentTimeMillis() - startTime

        // 5. Query DoH Multi-DNS Resolvers in parallel
        val dnsResolvers = queryDnsResolvers(cleanHost)

        // 6. Query Geo Location info for primary IP
        val geoInfo = primaryIp?.let { fetchGeoLocation(it) }

        HostDiagnosticResult(
            host = cleanHost,
            targetUrl = targetUrl,
            port = port,
            isHttps = isHttps,
            isSuccess = isSuccess || dnsRecords.isNotEmpty(),
            httpStatusCode = httpCode,
            httpStatusMessage = httpMessage,
            protocol = protocolName,
            responseTimeMs = if (isSuccess) responseTime else tcpPing.avgLatencyMs,
            serverHeader = serverHeader,
            cdnDetected = cdnDetected,
            ipAddresses = dnsRecords,
            reverseDns = reverseDns,
            headers = headersMap,
            sslInfo = sslInfo,
            tcpPingResult = tcpPing,
            geoInfo = geoInfo,
            dnsResolvers = dnsResolvers,
            errorDetail = errorDetail
        )
    }

    suspend fun pingTcpSocket(
        host: String,
        port: Int,
        attempts: Int = 3,
        timeoutMs: Int = 2500
    ): TcpPingResult = withContext(Dispatchers.IO) {
        val latencies = mutableListOf<Long>()
        var successful = 0

        for (i in 0 until attempts) {
            val tStart = System.currentTimeMillis()
            var sock: Socket? = null
            try {
                sock = Socket()
                sock.connect(InetSocketAddress(host, port), timeoutMs)
                val duration = System.currentTimeMillis() - tStart
                latencies.add(duration)
                successful++
            } catch (_: Exception) {
                // connection failed
            } finally {
                runCatching { sock?.close() }
            }
        }

        val minLatency = if (latencies.isNotEmpty()) latencies.minOrNull() ?: 0L else 0L
        val maxLatency = if (latencies.isNotEmpty()) latencies.maxOrNull() ?: 0L else 0L
        val avgLatency = if (latencies.isNotEmpty()) latencies.average().toLong() else 0L
        val lossPercent = if (attempts > 0) ((attempts - successful) * 100) / attempts else 0

        TcpPingResult(
            host = host,
            port = port,
            packetsSent = attempts,
            packetsReceived = successful,
            minLatencyMs = minLatency,
            avgLatencyMs = avgLatency,
            maxLatencyMs = maxLatency,
            packetLossPercent = lossPercent,
            latencies = latencies
        )
    }

    private fun fetchSslDetails(host: String, port: Int): SslCertificateInfo? {
        return try {
            val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            })

            val sslContext = SSLContext.getInstance("TLS")
            sslContext.init(null, trustAllCerts, java.security.SecureRandom())
            val factory = sslContext.socketFactory
            val socket = factory.createSocket() as SSLSocket
            socket.soTimeout = 4000
            socket.connect(InetSocketAddress(host, port), 4000)
            socket.startHandshake()

            val session = socket.session
            val peerCerts = session.peerCertificates
            val primaryCert = peerCerts.firstOrNull() as? X509Certificate

            val protocol = session.protocol ?: "TLS"
            val cipherSuite = session.cipherSuite ?: "Unknown"

            socket.close()

            if (primaryCert != null) {
                val now = System.currentTimeMillis()
                val validToMillis = primaryCert.notAfter.time
                val daysRemaining = ((validToMillis - now) / (1000 * 60 * 60 * 24)).coerceAtLeast(0)
                val isExpired = validToMillis < now

                val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
                val validFromStr = dateFormat.format(primaryCert.notBefore)
                val validToStr = dateFormat.format(primaryCert.notAfter)

                val subjectDn = primaryCert.subjectX500Principal.name
                val issuerDn = primaryCert.issuerX500Principal.name

                val subjectCn = extractDnComponent(subjectDn, "CN=")
                val subjectOrg = extractDnComponent(subjectDn, "O=")
                val issuerCn = extractDnComponent(issuerDn, "CN=")
                val issuerOrg = extractDnComponent(issuerDn, "O=")

                val sanList = mutableListOf<String>()
                runCatching {
                    primaryCert.subjectAlternativeNames?.forEach { item ->
                        if (item.size >= 2) {
                            val sanValue = item[1]?.toString()
                            if (!sanValue.isNullOrBlank()) sanList.add(sanValue)
                        }
                    }
                }

                SslCertificateInfo(
                    subjectCn = subjectCn.ifEmpty { host },
                    subjectOrg = subjectOrg,
                    issuerCn = issuerCn.ifEmpty { "Certificate Authority" },
                    issuerOrg = issuerOrg,
                    validFrom = validFromStr,
                    validTo = validToStr,
                    daysRemaining = daysRemaining,
                    isExpired = isExpired,
                    protocol = protocol,
                    cipherSuite = cipherSuite,
                    subjectAlternativeNames = sanList
                )
            } else null
        } catch (_: Exception) {
            null
        }
    }

    private fun extractDnComponent(dn: String, prefix: String): String {
        return dn.split(",").firstOrNull { it.trim().startsWith(prefix, ignoreCase = true) }
            ?.substringAfter("=")?.trim() ?: ""
    }

    private suspend fun queryDnsResolvers(host: String): List<DnsResolverResult> = coroutineScope {
        val resolvers = listOf(
            Triple("System DNS", "Local ISP", "system"),
            Triple("Cloudflare DoH", "1.1.1.1", "https://cloudflare-dns.com/dns-query?name=$host&type=A"),
            Triple("Google DoH", "8.8.8.8", "https://dns.google/resolve?name=$host&type=A"),
            Triple("Quad9 DoH", "9.9.9.9", "https://dns.quad9.net/dns-query?name=$host&type=A")
        )

        resolvers.map { (name, server, queryUrl) ->
            async(Dispatchers.IO) {
                val start = System.currentTimeMillis()
                if (queryUrl == "system") {
                    try {
                        val addrs = InetAddress.getAllByName(host).map { it.hostAddress ?: "" }.filter { it.isNotEmpty() }
                        val latency = System.currentTimeMillis() - start
                        DnsResolverResult(name, server, addrs, latency, isSuccess = addrs.isNotEmpty())
                    } catch (e: Exception) {
                        val latency = System.currentTimeMillis() - start
                        DnsResolverResult(name, server, emptyList(), latency, isSuccess = false, errorMessage = e.message)
                    }
                } else {
                    try {
                        val req = Request.Builder()
                            .url(queryUrl)
                            .header("Accept", "application/dns-json")
                            .build()
                        val resp = httpClient.newCall(req).execute()
                        val latency = System.currentTimeMillis() - start
                        val body = resp.body?.string() ?: ""
                        val ips = mutableListOf<String>()
                        if (resp.isSuccessful && body.isNotEmpty()) {
                            val json = JSONObject(body)
                            val answers = json.optJSONArray("Answer")
                            if (answers != null) {
                                for (i in 0 until answers.length()) {
                                    val ans = answers.optJSONObject(i)
                                    val data = ans?.optString("data")
                                    if (!data.isNullOrBlank() && !data.contains(".")) {
                                        // could be CNAME or IP
                                    }
                                    if (!data.isNullOrBlank()) {
                                        ips.add(data)
                                    }
                                }
                            }
                        }
                        DnsResolverResult(name, server, ips, latency, isSuccess = ips.isNotEmpty())
                    } catch (e: Exception) {
                        val latency = System.currentTimeMillis() - start
                        DnsResolverResult(name, server, emptyList(), latency, isSuccess = false, errorMessage = e.message)
                    }
                }
            }
        }.awaitAll()
    }

    private suspend fun fetchGeoLocation(ip: String): GeoLocationInfo? = withContext(Dispatchers.IO) {
        if (ip.startsWith("127.") || ip.startsWith("10.") || ip.startsWith("192.168.") || ip == "::1") {
            return@withContext GeoLocationInfo(
                ip = ip,
                country = "Local Network",
                countryCode = "LOC",
                flagEmoji = "🏠"
            )
        }
        try {
            // Use public RDAP/Geo IP service
            val url = "https://ipwho.is/$ip"
            val req = Request.Builder().url(url).build()
            val resp = httpClient.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            if (resp.isSuccessful && body.isNotEmpty()) {
                val json = JSONObject(body)
                if (json.optBoolean("success", true)) {
                    val country = json.optString("country", "Unknown")
                    val countryCode = json.optString("country_code", "")
                    val flag = json.optJSONObject("flag")?.optString("emoji", "") ?: getFlagEmoji(countryCode)
                    val city = json.optString("city", "")
                    val region = json.optString("region", "")
                    val connection = json.optJSONObject("connection")
                    val isp = connection?.optString("isp", "") ?: ""
                    val org = connection?.optString("org", "") ?: ""
                    val asn = connection?.optString("asn", "") ?: ""
                    val tz = json.optJSONObject("timezone")?.optString("id", "") ?: ""

                    return@withContext GeoLocationInfo(
                        ip = ip,
                        country = country,
                        countryCode = countryCode,
                        region = region,
                        city = city,
                        isp = isp,
                        org = org,
                        asNumber = if (asn.isNotEmpty()) "AS$asn" else "",
                        timezone = tz,
                        flagEmoji = flag.ifEmpty { getFlagEmoji(countryCode) }
                    )
                }
            }
        } catch (_: Exception) {
            // Fallback flag by IP or simple placeholder
        }
        null
    }

    fun detectCdn(headers: Map<String, String>, server: String?, host: String): String {
        val serverLower = server?.lowercase() ?: ""
        val lowerKeys = headers.keys.map { it.lowercase() }.toSet()

        if (serverLower.contains("cloudflare") || lowerKeys.contains("cf-ray") || lowerKeys.contains("cf-cache-status")) {
            return "Cloudflare CDN"
        }
        if (serverLower.contains("akamai") || lowerKeys.contains("x-akamai-transformed") || lowerKeys.contains("x-akamai-session-info")) {
            return "Akamai Technologies"
        }
        if (serverLower.contains("cloudfront") || lowerKeys.contains("x-amz-cf-id") || lowerKeys.contains("x-amz-cf-pop")) {
            return "Amazon CloudFront"
        }
        if (serverLower.contains("fastly") || lowerKeys.contains("x-fastly-request-id") || lowerKeys.contains("fastly-debug-digest")) {
            return "Fastly CDN"
        }
        if (serverLower.contains("gws") || serverLower.contains("gse") || lowerKeys.contains("x-goog-generation")) {
            return "Google Cloud CDN / GFE"
        }
        if (serverLower.contains("imperva") || lowerKeys.contains("x-iinfo")) {
            return "Imperva Incapsula"
        }
        if (serverLower.contains("bunny") || lowerKeys.contains("b-cache")) {
            return "Bunny.net CDN"
        }
        if (serverLower.contains("varnish") || lowerKeys.contains("x-varnish")) {
            return "Varnish Cache Edge"
        }
        if (lowerKeys.contains("x-azure-ref") || serverLower.contains("azure")) {
            return "Microsoft Azure CDN"
        }
        if (serverLower.contains("nginx")) {
            return "Nginx Web Server"
        }
        if (serverLower.contains("apache")) {
            return "Apache HTTP Server"
        }
        if (serverLower.contains("caddy")) {
            return "Caddy Server"
        }
        if (!server.isNullOrBlank()) {
            return server
        }
        return "Direct Origin / Unknown Edge"
    }

    fun sanitizeHost(input: String): String {
        var clean = input.trim()
        if (clean.startsWith("http://", ignoreCase = true)) {
            clean = clean.substring(7)
        } else if (clean.startsWith("https://", ignoreCase = true)) {
            clean = clean.substring(8)
        }
        if (clean.contains("/")) {
            clean = clean.substringBefore("/")
        }
        if (clean.contains(":")) {
            clean = clean.substringBefore(":")
        }
        return clean.trim()
    }

    private fun getFlagEmoji(countryCode: String): String {
        if (countryCode.length != 2) return "🌐"
        val firstChar = Character.codePointAt(countryCode.uppercase(), 0) - 0x41 + 0x1F1E6
        val secondChar = Character.codePointAt(countryCode.uppercase(), 1) - 0x41 + 0x1F1E6
        return String(Character.toChars(firstChar)) + String(Character.toChars(secondChar))
    }
}
