package com.example.data

data class HostDiagnosticResult(
    val host: String,
    val targetUrl: String,
    val port: Int = 443,
    val isHttps: Boolean = true,
    val isSuccess: Boolean = false,
    val httpStatusCode: Int? = null,
    val httpStatusMessage: String? = null,
    val protocol: String? = null,
    val responseTimeMs: Long = 0,
    val serverHeader: String? = null,
    val cdnDetected: String? = null,
    val ipAddresses: List<String> = emptyList(),
    val reverseDns: String? = null,
    val headers: Map<String, String> = emptyMap(),
    val sslInfo: SslCertificateInfo? = null,
    val tcpPingResult: TcpPingResult? = null,
    val geoInfo: GeoLocationInfo? = null,
    val dnsResolvers: List<DnsResolverResult> = emptyList(),
    val errorDetail: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class SslCertificateInfo(
    val subjectCn: String = "",
    val subjectOrg: String = "",
    val issuerCn: String = "",
    val issuerOrg: String = "",
    val validFrom: String = "",
    val validTo: String = "",
    val daysRemaining: Long = 0,
    val isExpired: Boolean = false,
    val protocol: String = "",
    val cipherSuite: String = "",
    val subjectAlternativeNames: List<String> = emptyList()
)

data class TcpPingResult(
    val host: String,
    val port: Int,
    val packetsSent: Int = 0,
    val packetsReceived: Int = 0,
    val minLatencyMs: Long = 0,
    val avgLatencyMs: Long = 0,
    val maxLatencyMs: Long = 0,
    val packetLossPercent: Int = 0,
    val latencies: List<Long> = emptyList()
)

data class GeoLocationInfo(
    val ip: String = "",
    val country: String = "",
    val countryCode: String = "",
    val region: String = "",
    val city: String = "",
    val isp: String = "",
    val org: String = "",
    val asNumber: String = "",
    val timezone: String = "",
    val flagEmoji: String = ""
)

data class DnsResolverResult(
    val resolverName: String,
    val resolverServer: String,
    val resolvedIps: List<String> = emptyList(),
    val latencyMs: Long = 0,
    val isSuccess: Boolean = false,
    val errorMessage: String? = null
)

data class BatchHostItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val host: String,
    val status: BatchScanStatus = BatchScanStatus.IDLE,
    val statusCode: Int? = null,
    val latencyMs: Long? = null,
    val server: String? = null,
    val cdn: String? = null,
    val resolvedIp: String? = null,
    val error: String? = null
)

enum class BatchScanStatus {
    IDLE,
    SCANNING,
    SUCCESS,
    FAILED
}

data class CountryPreset(
    val name: String,
    val code: String,
    val flag: String,
    val region: String,
    val hosts: List<String>
)
