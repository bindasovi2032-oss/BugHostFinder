package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DnsResolverResult
import com.example.data.GeoLocationInfo
import com.example.data.SslCertificateInfo
import com.example.data.TcpPingResult
import com.example.ui.theme.BentoAmber
import com.example.ui.theme.BentoAmberContainer
import com.example.ui.theme.BentoBlue
import com.example.ui.theme.BentoBorder
import com.example.ui.theme.BentoBorderDark
import com.example.ui.theme.BentoCyan
import com.example.ui.theme.BentoDarkTile
import com.example.ui.theme.BentoGreenAccent
import com.example.ui.theme.BentoGreenSage
import com.example.ui.theme.BentoGreenSageSoft
import com.example.ui.theme.BentoPrimaryGreen
import com.example.ui.theme.BentoRed
import com.example.ui.theme.BentoRedContainer
import com.example.ui.theme.BentoTextLight
import com.example.ui.theme.BentoTextLightMuted
import com.example.ui.theme.BentoTextMuted
import com.example.ui.theme.BentoTextPrimary
import com.example.ui.theme.BentoTextSecondary

@Composable
fun HttpStatusBadge(
    code: Int?,
    message: String?,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, text) = when {
        code == null -> Triple(BentoGreenSageSoft, BentoTextMuted, "NO RESPONSE")
        code in 200..299 -> Triple(BentoGreenSage, BentoPrimaryGreen, "$code ${message ?: "OK"}")
        code in 300..399 -> Triple(Color(0xFFE0F2FE), BentoBlue, "$code ${message ?: "Redirect"}")
        code in 400..499 -> Triple(BentoAmberContainer, BentoAmber, "$code ${message ?: "Client Error"}")
        code in 500..599 -> Triple(BentoRedContainer, BentoRed, "$code ${message ?: "Server Error"}")
        else -> Triple(BentoGreenSageSoft, BentoTextPrimary, "$code ${message ?: ""}")
    }

    Surface(
        modifier = modifier.clip(RoundedCornerShape(50)),
        color = bgColor,
        shape = RoundedCornerShape(50)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(textColor)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = text,
                color = textColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun MetricTile(
    title: String,
    value: String,
    icon: ImageVector,
    accentColor: Color = BentoPrimaryGreen,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .border(1.dp, BentoBorder, RoundedCornerShape(20.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(BentoGreenSageSoft),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Column {
                Text(
                    text = title.uppercase(),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp,
                    color = BentoTextSecondary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = BentoTextPrimary,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun BentoStatusBanner(
    title: String,
    subtitle: String,
    statusLabel: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, BentoBorderDark, RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = BentoGreenSage),
        shape = RoundedCornerShape(24.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "STATUS",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = BentoPrimaryGreen
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = BentoTextPrimary
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = BentoTextSecondary
                )
            }
            Surface(
                shape = RoundedCornerShape(50),
                color = Color.White
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(BentoPrimaryGreen)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = statusLabel,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BentoPrimaryGreen
                    )
                }
            }
        }
    }
}

@Composable
fun BentoActiveProcessHero(
    title: String,
    mainValue: String,
    subValue: String,
    processNote: String,
    progress: Float? = null,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = BentoDarkTile),
        shape = RoundedCornerShape(24.dp)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            // Decorative subtle glow circle in corner
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .align(Alignment.TopEnd)
                    .background(
                        BentoPrimaryGreen.copy(alpha = 0.25f),
                        CircleShape
                    )
            )

            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = title.uppercase(),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp,
                    color = BentoGreenAccent
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = mainValue,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Light,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = subValue,
                        fontSize = 13.sp,
                        color = BentoTextLightMuted,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }

                if (progress != null) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(Color(0xFF42493F))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(progress.coerceIn(0f, 1f))
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(BentoGreenAccent)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = processNote,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = BentoTextLightMuted
                )
            }
        }
    }
}

@Composable
fun GeoLocationCard(
    geo: GeoLocationInfo?,
    modifier: Modifier = Modifier
) {
    if (geo == null) return

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, BentoBorder, RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(BentoGreenSageSoft),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = geo.flagEmoji, fontSize = 22.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "REGION & LOCATION",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp,
                            color = BentoTextSecondary
                        )
                        Text(
                            text = if (geo.city.isNotEmpty()) "${geo.city}, ${geo.country}" else geo.country,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = BentoTextPrimary
                        )
                    }
                }
                if (geo.countryCode.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = BentoGreenSage
                    ) {
                        Text(
                            text = geo.countryCode,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            color = BentoPrimaryGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (geo.isp.isNotEmpty() || geo.asNumber.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (geo.isp.isNotEmpty()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "CARRIER / ISP",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.6.sp,
                                color = BentoTextMuted
                            )
                            Text(
                                text = geo.isp,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = BentoTextPrimary
                            )
                        }
                    }
                    if (geo.asNumber.isNotEmpty()) {
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "AUTONOMOUS SYSTEM",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.6.sp,
                                color = BentoTextMuted
                            )
                            Text(
                                text = geo.asNumber,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = BentoPrimaryGreen
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SslCertificateCard(
    ssl: SslCertificateInfo?,
    modifier: Modifier = Modifier
) {
    if (ssl == null) return
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, BentoBorder, RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(if (ssl.isExpired) BentoRedContainer else BentoGreenSageSoft),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (ssl.isExpired) Icons.Default.Error else Icons.Default.Lock,
                            contentDescription = null,
                            tint = if (ssl.isExpired) BentoRed else BentoPrimaryGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "SECURITY & TLS",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp,
                            color = BentoTextSecondary
                        )
                        Text(
                            text = "SSL Certificate",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = BentoTextPrimary
                        )
                    }
                }
                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (ssl.isExpired) BentoRedContainer else BentoGreenSage
                ) {
                    Text(
                        text = if (ssl.isExpired) "EXPIRED" else "${ssl.daysRemaining}d left",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        color = if (ssl.isExpired) BentoRed else BentoPrimaryGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            DetailRow(label = "Issued To (CN)", value = ssl.subjectCn)
            DetailRow(label = "Issuer Authority", value = ssl.issuerCn)
            DetailRow(label = "Protocol & Cipher", value = "${ssl.protocol} (${ssl.cipherSuite})")
            DetailRow(label = "Valid Until", value = ssl.validTo)

            if (ssl.subjectAlternativeNames.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { expanded = !expanded }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Subject Alternative Names (${ssl.subjectAlternativeNames.size})",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = BentoPrimaryGreen
                    )
                    Icon(
                        imageVector = if (expanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                        contentDescription = null,
                        tint = BentoPrimaryGreen
                    )
                }

                AnimatedVisibility(visible = expanded) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp)
                            .background(
                                BentoGreenSageSoft,
                                RoundedCornerShape(12.dp)
                            )
                            .padding(12.dp)
                    ) {
                        ssl.subjectAlternativeNames.take(20).forEach { san ->
                            Text(
                                text = "• $san",
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = FontFamily.Monospace,
                                color = BentoTextSecondary
                            )
                        }
                        if (ssl.subjectAlternativeNames.size > 20) {
                            Text(
                                text = "+ ${ssl.subjectAlternativeNames.size - 20} more domains...",
                                style = MaterialTheme.typography.labelSmall,
                                color = BentoTextMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DnsResolversCard(
    resolvers: List<DnsResolverResult>,
    modifier: Modifier = Modifier
) {
    if (resolvers.isEmpty()) return

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, BentoBorder, RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(BentoGreenSageSoft),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Dns,
                        contentDescription = null,
                        tint = BentoPrimaryGreen,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "GLOBAL DNS PROPAGATION",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp,
                        color = BentoTextSecondary
                    )
                    Text(
                        text = "Multi-Resolver Matrix",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = BentoTextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            resolvers.forEach { res ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${res.resolverName} (${res.resolverServer})",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = BentoTextPrimary
                        )
                        Text(
                            text = if (res.resolvedIps.isNotEmpty()) res.resolvedIps.joinToString(", ") else res.errorMessage ?: "No record",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = if (res.isSuccess) BentoTextSecondary else BentoRed,
                            maxLines = 2
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = if (res.isSuccess) BentoGreenSage else BentoRedContainer
                    ) {
                        Text(
                            text = if (res.isSuccess) "${res.latencyMs}ms" else "ERR",
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                            color = if (res.isSuccess) BentoPrimaryGreen else BentoRed,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TcpPingCard(
    ping: TcpPingResult?,
    modifier: Modifier = Modifier
) {
    if (ping == null) return

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, BentoBorder, RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(BentoGreenSageSoft),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = null,
                            tint = BentoPrimaryGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "SOCKET LATENCY",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp,
                            color = BentoTextSecondary
                        )
                        Text(
                            text = "Port ${ping.port} Latency",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = BentoTextPrimary
                        )
                    }
                }
                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (ping.packetLossPercent == 0) BentoGreenSage else BentoAmberContainer
                ) {
                    Text(
                        text = "${ping.packetLossPercent}% loss",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        color = if (ping.packetLossPercent == 0) BentoPrimaryGreen else BentoAmber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatPill(label = "MIN", value = "${ping.minLatencyMs}ms", color = BentoPrimaryGreen, modifier = Modifier.weight(1f))
                StatPill(label = "AVG", value = "${ping.avgLatencyMs}ms", color = BentoCyan, modifier = Modifier.weight(1f))
                StatPill(label = "MAX", value = "${ping.maxLatencyMs}ms", color = BentoAmber, modifier = Modifier.weight(1f))
                StatPill(label = "PKTS", value = "${ping.packetsReceived}/${ping.packetsSent}", color = BentoBlue, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun StatPill(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .background(BentoGreenSageSoft, RoundedCornerShape(16.dp))
            .border(1.dp, BentoBorder, RoundedCornerShape(16.dp))
            .padding(horizontal = 8.dp, vertical = 10.dp)
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp,
            color = BentoTextMuted
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = color
        )
    }
}

@Composable
fun HttpHeadersCard(
    headers: Map<String, String>,
    modifier: Modifier = Modifier
) {
    if (headers.isEmpty()) return
    var expanded by remember { mutableStateOf(false) }
    val clipboardManager = LocalClipboardManager.current

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, BentoBorder, RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(BentoGreenSageSoft),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = BentoPrimaryGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "METADATA",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp,
                            color = BentoTextSecondary
                        )
                        Text(
                            text = "Response Headers (${headers.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = BentoTextPrimary
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            val text = headers.entries.joinToString("\n") { "${it.key}: ${it.value}" }
                            clipboardManager.setText(AnnotatedString(text))
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy Headers",
                            tint = BentoTextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Icon(
                        imageVector = if (expanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                        contentDescription = null,
                        tint = BentoTextSecondary
                    )
                }
            }

            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                        .background(
                            BentoGreenSageSoft,
                            RoundedCornerShape(14.dp)
                        )
                        .padding(12.dp)
                ) {
                    headers.forEach { (k, v) ->
                        Column(modifier = Modifier.padding(vertical = 3.dp)) {
                            Text(
                                text = k,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = BentoPrimaryGreen
                            )
                            Text(
                                text = v,
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = FontFamily.Monospace,
                                color = BentoTextPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    if (value.isBlank()) return
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = BentoTextSecondary
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.Monospace,
            color = BentoTextPrimary,
            maxLines = 1
        )
    }
}
