package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BatchHostItem
import com.example.data.BatchScanStatus
import com.example.ui.components.BentoActiveProcessHero
import com.example.ui.components.BentoStatusBanner
import com.example.ui.components.HttpStatusBadge
import com.example.ui.theme.BentoAmber
import com.example.ui.theme.BentoBorder
import com.example.ui.theme.BentoGreenAccent
import com.example.ui.theme.BentoGreenSage
import com.example.ui.theme.BentoGreenSageSoft
import com.example.ui.theme.BentoPrimaryGreen
import com.example.ui.theme.BentoRed
import com.example.ui.theme.BentoRedContainer
import com.example.ui.theme.BentoTextMuted
import com.example.ui.theme.BentoTextPrimary
import com.example.ui.theme.BentoTextSecondary
import com.example.ui.viewmodel.DiagnosticViewModel

@Composable
fun BatchScannerScreen(
    viewModel: DiagnosticViewModel,
    onNavigateToSingle: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val batchText by viewModel.batchText.collectAsState()
    val batchItems by viewModel.batchItems.collectAsState()
    val isScanning by viewModel.isBatchScanning.collectAsState()
    val progress by viewModel.batchProgress.collectAsState()
    val countryPresets = viewModel.countryPresets
    val selectedCountry by viewModel.selectedCountry.collectAsState()

    var showCountryMenu by remember { mutableStateOf(false) }
    var filterStatus by remember { mutableStateOf<String>("ALL") }

    val filteredItems = remember(batchItems, filterStatus) {
        when (filterStatus) {
            "2XX" -> batchItems.filter { it.statusCode in 200..299 }
            "3XX" -> batchItems.filter { it.statusCode in 300..399 }
            "ERR" -> batchItems.filter { it.status == BatchScanStatus.FAILED || (it.statusCode != null && it.statusCode !in 200..399) }
            else -> batchItems
        }
    }

    val successCount = remember(batchItems) { batchItems.count { it.statusCode in 200..299 } }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Bento Status Banner
        BentoStatusBanner(
            title = if (isScanning) "Multi-Host Batch Scanning" else "Batch Benchmark Ready",
            subtitle = "${batchItems.size} targets queued • $successCount responsive",
            statusLabel = if (isScanning) "ACTIVE" else "READY"
        )

        if (isScanning || batchItems.isNotEmpty()) {
            BentoActiveProcessHero(
                title = "BATCH SCAN PROGRESS",
                mainValue = "$successCount",
                subValue = "Hosts Found (${(progress * 100).toInt()}%)",
                processNote = if (isScanning) "Benchmarking parallel DNS & HTTP responses..." else "Batch scan complete. Filter or inspect below.",
                progress = progress
            )
        }

        // Input Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BentoBorder, RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = "TARGETS CONFIGURATION",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp,
                            color = BentoTextSecondary
                        )
                        Text(
                            text = "Batch Host List",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = BentoTextPrimary
                        )
                    }

                    // Preset Selector
                    Box {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = BentoGreenSageSoft,
                            modifier = Modifier
                                .border(1.dp, BentoBorder, RoundedCornerShape(50))
                                .clickable { showCountryMenu = true }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("${selectedCountry.flag} ${selectedCountry.name}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BentoPrimaryGreen)
                            }
                        }

                        DropdownMenu(
                            expanded = showCountryMenu,
                            onDismissRequest = { showCountryMenu = false }
                        ) {
                            countryPresets.forEach { preset ->
                                DropdownMenuItem(
                                    text = { Text("${preset.flag} ${preset.name} (${preset.region})") },
                                    onClick = {
                                        viewModel.loadCountryPresetIntoBatch(preset)
                                        showCountryMenu = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = batchText,
                    onValueChange = { viewModel.setBatchText(it) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp),
                    placeholder = { Text("Enter domain names, one per line\ne.g. cloudflare.com\ngoogle.com") },
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BentoPrimaryGreen,
                        unfocusedBorderColor = BentoBorder,
                        focusedContainerColor = BentoGreenSageSoft,
                        unfocusedContainerColor = BentoGreenSageSoft
                    ),
                    textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (isScanning) {
                    Button(
                        onClick = { viewModel.stopBatchScan() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(containerColor = BentoRed, contentColor = Color.White)
                    ) {
                        Icon(imageVector = Icons.Default.Stop, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("STOP BATCH SCAN", fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                    }
                } else {
                    Button(
                        onClick = { viewModel.startBatchScan() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BentoPrimaryGreen,
                            contentColor = Color.White
                        ),
                        enabled = batchText.isNotBlank()
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("INITIALIZE BATCH SCAN", fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                    }
                }
            }
        }

        // Filter Bar
        if (batchItems.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TARGETS (${filteredItems.size}/${batchItems.size})",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp,
                    color = BentoTextSecondary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("ALL", "2XX", "3XX", "ERR").forEach { f ->
                        FilterChip(
                            selected = filterStatus == f,
                            onClick = { filterStatus = f },
                            label = { Text(f, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BentoGreenSage,
                                selectedLabelColor = BentoPrimaryGreen
                            )
                        )
                    }
                }
            }
        }

        // List of Batch Results
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filteredItems, key = { it.id }) { item ->
                BatchItemCard(
                    item = item,
                    onClick = {
                        viewModel.runSingleDiagnostic(item.host)
                        onNavigateToSingle(item.host)
                    }
                )
            }
        }
    }
}

@Composable
fun BatchItemCard(
    item: BatchHostItem,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BentoBorder, RoundedCornerShape(18.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.host,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = BentoTextPrimary
                )
                if (item.resolvedIp != null) {
                    Text(
                        text = item.resolvedIp,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = BentoTextSecondary
                    )
                }
                if (item.cdn != null) {
                    Text(
                        text = item.cdn,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = BentoPrimaryGreen
                    )
                }
            }

            when (item.status) {
                BatchScanStatus.IDLE -> {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = BentoGreenSageSoft
                    ) {
                        Text(
                            text = "QUEUED",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            color = BentoTextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                BatchScanStatus.SCANNING -> {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = BentoPrimaryGreen,
                        strokeWidth = 2.dp
                    )
                }
                BatchScanStatus.SUCCESS -> {
                    Column(horizontalAlignment = Alignment.End) {
                        HttpStatusBadge(
                            code = item.statusCode,
                            message = null
                        )
                        if (item.latencyMs != null) {
                            Text(
                                text = "${item.latencyMs}ms",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = if (item.latencyMs < 200) BentoPrimaryGreen else BentoAmber
                            )
                        }
                    }
                }
                BatchScanStatus.FAILED -> {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = BentoRedContainer
                    ) {
                        Text(
                            text = "FAILED",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            color = BentoRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
