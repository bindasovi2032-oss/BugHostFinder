package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.ListAlt
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.BentoBorder
import com.example.ui.theme.BentoBorderDark
import com.example.ui.theme.BentoCanvas
import com.example.ui.theme.BentoGreenSage
import com.example.ui.theme.BentoGreenSageSoft
import com.example.ui.theme.BentoPrimaryGreen
import com.example.ui.theme.BentoTextMuted
import com.example.ui.theme.BentoTextPrimary
import com.example.ui.theme.BentoTextSecondary
import com.example.ui.viewmodel.DiagnosticViewModel

enum class NavTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    SINGLE("Scanner", Icons.Filled.Search, Icons.Outlined.Search),
    BATCH("Batch", Icons.Filled.ListAlt, Icons.Outlined.ListAlt),
    WORLDWIDE("Region", Icons.Filled.Public, Icons.Outlined.Public),
    PING("Socket", Icons.Filled.Speed, Icons.Outlined.Speed),
    HISTORY("History", Icons.Filled.History, Icons.Outlined.History)
}

@Composable
fun MainAppScreen(
    viewModel: DiagnosticViewModel,
    modifier: Modifier = Modifier
) {
    var currentTab by remember { mutableStateOf(NavTab.SINGLE) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = BentoCanvas,
        topBar = {
            // Bento Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(BentoPrimaryGreen),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "B",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Bug Host Finder",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = BentoTextPrimary
                        )
                        Text(
                            text = "COM.BUGHOSTFINDER.ALLCOUNTRY",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.5.sp,
                            color = BentoTextMuted
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = BentoGreenSageSoft,
                    modifier = Modifier.border(1.dp, BentoBorder, RoundedCornerShape(50))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(BentoPrimaryGreen)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "v4.2 PRO",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BentoPrimaryGreen
                        )
                    }
                }
            }
        },
        bottomBar = {
            // Bento Navigation Bar with soft sage container and pill indicators
            NavigationBar(
                modifier = Modifier
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .border(1.dp, BentoBorderDark, RoundedCornerShape(28.dp)),
                containerColor = BentoGreenSageSoft,
                tonalElevation = 0.dp
            ) {
                NavTab.values().forEach { tab ->
                    val selected = currentTab == tab
                    NavigationBarItem(
                        selected = selected,
                        onClick = { currentTab = tab },
                        icon = {
                            Icon(
                                imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                contentDescription = tab.title,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 10.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BentoTextPrimary,
                            selectedTextColor = BentoTextPrimary,
                            indicatorColor = BentoGreenSage,
                            unselectedIconColor = BentoTextSecondary.copy(alpha = 0.7f),
                            unselectedTextColor = BentoTextSecondary.copy(alpha = 0.7f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BentoCanvas)
        ) {
            when (currentTab) {
                NavTab.SINGLE -> SingleHostScreen(
                    viewModel = viewModel
                )
                NavTab.BATCH -> BatchScannerScreen(
                    viewModel = viewModel,
                    onNavigateToSingle = {
                        currentTab = NavTab.SINGLE
                    }
                )
                NavTab.WORLDWIDE -> WorldwideScreen(
                    viewModel = viewModel,
                    onNavigateToSingle = {
                        currentTab = NavTab.SINGLE
                    },
                    onNavigateToBatch = {
                        currentTab = NavTab.BATCH
                    }
                )
                NavTab.PING -> TcpPingScreen(
                    viewModel = viewModel
                )
                NavTab.HISTORY -> HistoryScreen(
                    viewModel = viewModel,
                    onSelectHistory = {
                        currentTab = NavTab.SINGLE
                    }
                )
            }
        }
    }
}
