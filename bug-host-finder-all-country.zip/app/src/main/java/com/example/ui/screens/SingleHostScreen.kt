package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Http
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BentoActiveProcessHero
import com.example.ui.components.BentoStatusBanner
import com.example.ui.components.DnsResolversCard
import com.example.ui.components.GeoLocationCard
import com.example.ui.components.HttpHeadersCard
import com.example.ui.components.HttpStatusBadge
import com.example.ui.components.MetricTile
import com.example.ui.components.SslCertificateCard
import com.example.ui.components.TcpPingCard
import com.example.ui.theme.BentoAmber
import com.example.ui.theme.BentoBlue
import com.example.ui.theme.BentoBorder
import com.example.ui.theme.BentoCyan
import com.example.ui.theme.BentoGreenAccent
import com.example.ui.theme.BentoGreenSage
import com.example.ui.theme.BentoGreenSageSoft
import com.example.ui.theme.BentoPrimaryGreen
import com.example.ui.theme.BentoPrimaryGreenDark
import com.example.ui.theme.BentoRed
import com.example.ui.theme.BentoTextMuted
import com.example.ui.theme.BentoTextPrimary
import com.example.ui.theme.BentoTextSecondary
import com.example.ui.viewmodel.DiagnosticViewModel

@Composable
fun SingleHostScreen(
    viewModel: DiagnosticViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val hostInput by viewModel.singleHostInput.collectAsState()
    val selectedPort by viewModel.selectedPort.collectAsState()
    val selectedMethod by viewModel.selectedMethod.collectAsState()
    val followRedirects by viewModel.followRedirects.collectAsState()
    val isDiagnosing by viewModel.isDiagnosing.collectAsState()
    val result by viewModel.diagnosticResult.collectAsState()

    var showOptions by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Bento Status Banner
        BentoStatusBanner(
            title = if (isDiagnosing) "Analyzing Host..." else if (result != null) "Scan Finished" else "Scanner Ready",
            subtitle = "Global Diagnostic Node v4.2",
            statusLabel = if (isDiagnosing) "LIVE" else "READY"
        )

        // Bento Host Search Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BentoBorder, RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "TARGET DOMAIN OR IP",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = BentoTextSecondary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Host & SNI Diagnostic",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = BentoTextPrimary
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = hostInput,
                    onValueChange = { viewModel.setSingleHostInput(it) },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("e.g. cloudflare.com or 1.1.1.1") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = BentoPrimaryGreen
                        )
                    },
                    trailingIcon = {
                        IconButton(onClick = { showOptions = !showOptions }) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = "Options",
                                tint = if (showOptions) BentoPrimaryGreen else BentoTextMuted
                            )
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Uri,
                        imeAction = ImeAction.Go
                    ),
                    keyboardActions = KeyboardActions(
                        onGo = {
                            focusManager.clearFocus()
                            viewModel.runSingleDiagnostic()
                        }
                    ),
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BentoPrimaryGreen,
                        unfocusedBorderColor = BentoBorder,
                        focusedContainerColor = BentoGreenSageSoft,
                        unfocusedContainerColor = BentoGreenSageSoft
                    )
                )

                // Advanced Options
                AnimatedVisibility(visible = showOptions) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp)
                            .background(BentoGreenSageSoft, RoundedCornerShape(16.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "DIAGNOSTIC PARAMETERS",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp,
                            color = BentoPrimaryGreen
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // Port Selection
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = "Port", style = MaterialTheme.typography.bodySmall, color = BentoTextSecondary)
                            Row {
                                listOf(443, 80, 8080, 8443).forEach { p ->
                                    FilterChip(
                                        selected = selectedPort == p,
                                        onClick = { viewModel.setSelectedPort(p) },
                                        label = { Text(p.toString(), fontSize = 11.sp) },
                                        modifier = Modifier.padding(start = 4.dp),
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = BentoGreenSage,
                                            selectedLabelColor = BentoPrimaryGreen
                                        )
                                    )
                                }
                            }
                        }

                        // HTTP Method Selection
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                        ) {
                            Text(text = "HTTP Method", style = MaterialTheme.typography.bodySmall, color = BentoTextSecondary)
                            Row {
                                listOf("GET", "HEAD", "OPTIONS").forEach { m ->
                                    FilterChip(
                                        selected = selectedMethod == m,
                                        onClick = { viewModel.setSelectedMethod(m) },
                                        label = { Text(m, fontSize = 11.sp) },
                                        modifier = Modifier.padding(start = 4.dp),
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = BentoGreenSage,
                                            selectedLabelColor = BentoPrimaryGreen
                                        )
                                    )
                                }
                            }
                        }

                        // Follow Redirects Switch
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                        ) {
                            Text(text = "Follow Redirects", style = MaterialTheme.typography.bodySmall, color = BentoTextSecondary)
                            Switch(
                                checked = followRedirects,
                                onCheckedChange = { viewModel.setFollowRedirects(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = BentoPrimaryGreen,
                                    checkedTrackColor = BentoGreenSage
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Bento Pill Action Button
                Button(
                    onClick = {
                        focusManager.clearFocus()
                        viewModel.runSingleDiagnostic()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BentoPrimaryGreen,
                        contentColor = Color.White
                    ),
                    enabled = !isDiagnosing && hostInput.isNotBlank()
                ) {
                    if (isDiagnosing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = Color.White,
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("SCANNING ENDPOINTS...", fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                    } else {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("INITIALIZE LIVE SCAN", fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                    }
                }
            }
        }

        // Active Diagnostics / Result Section
        if (isDiagnosing && result == null) {
            BentoActiveProcessHero(
                title = "ACTIVE PROCESS",
                mainValue = "...",
                subValue = "Analyzing Host",
                processNote = "Querying DNS resolvers, TLS handshake & HTTP ping...",
                progress = 0.45f
            )
        }

        result?.let { res ->
            // Bento Dark Hero Card showing live status
            BentoActiveProcessHero(
                title = "ACTIVE PROCESS",
                mainValue = if (res.httpStatusCode != null) "${res.httpStatusCode}" else "ERR",
                subValue = res.httpStatusMessage ?: if (res.isSuccess) "Success" else "Failed",
                processNote = "Resolved ${res.host} via ${res.cdnDetected ?: "Direct Origin"} in ${res.responseTimeMs}ms",
                progress = 1.0f
            )

            // Top Overview Card with Share
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BentoBorder, RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = res.host,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = BentoTextPrimary
                            )
                            Text(
                                text = res.targetUrl,
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = FontFamily.Monospace,
                                color = BentoTextSecondary
                            )
                        }
                        IconButton(
                            onClick = { viewModel.shareDiagnosticReport(context, res) },
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(BentoGreenSageSoft)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Share Report",
                                tint = BentoPrimaryGreen,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        HttpStatusBadge(
                            code = res.httpStatusCode,
                            message = res.httpStatusMessage
                        )

                        if (!res.cdnDetected.isNullOrBlank()) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = BentoGreenSage
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Cloud,
                                        contentDescription = null,
                                        tint = BentoPrimaryGreen,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = res.cdnDetected,
                                        color = BentoPrimaryGreen,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    if (!res.errorDetail.isNullOrBlank() && !res.isSuccess) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(BentoRed.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                .padding(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Error,
                                contentDescription = null,
                                tint = BentoRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = res.errorDetail,
                                color = BentoRed,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }

            // Bento Metric Tiles 2x2 Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricTile(
                    title = "Latency",
                    value = "${res.responseTimeMs} ms",
                    icon = Icons.Default.Speed,
                    accentColor = BentoPrimaryGreen,
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    title = "Protocol",
                    value = res.protocol ?: if (res.isHttps) "HTTPS" else "HTTP",
                    icon = Icons.Default.Http,
                    accentColor = BentoBlue,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricTile(
                    title = "Server Edge",
                    value = res.serverHeader ?: "Direct Origin",
                    icon = Icons.Default.Cloud,
                    accentColor = BentoCyan,
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    title = "DNS Records",
                    value = if (res.ipAddresses.isNotEmpty()) "${res.ipAddresses.size} IPs Found" else "0 Found",
                    icon = Icons.Default.Dns,
                    accentColor = BentoPrimaryGreen,
                    modifier = Modifier.weight(1f)
                )
            }

            // GeoLocation Card
            GeoLocationCard(geo = res.geoInfo)

            // SSL Certificate Card
            SslCertificateCard(ssl = res.sslInfo)

            // TCP Ping Details
            TcpPingCard(ping = res.tcpPingResult)

            // Multi DNS Propagation Matrix
            DnsResolversCard(resolvers = res.dnsResolvers)

            // HTTP Response Headers
            HttpHeadersCard(headers = res.headers)

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
