package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BentoActiveProcessHero
import com.example.ui.components.BentoStatusBanner
import com.example.ui.components.StatPill
import com.example.ui.theme.BentoAmber
import com.example.ui.theme.BentoAmberContainer
import com.example.ui.theme.BentoBlue
import com.example.ui.theme.BentoBorder
import com.example.ui.theme.BentoCyan
import com.example.ui.theme.BentoGreenSage
import com.example.ui.theme.BentoGreenSageSoft
import com.example.ui.theme.BentoPrimaryGreen
import com.example.ui.theme.BentoTextMuted
import com.example.ui.theme.BentoTextPrimary
import com.example.ui.theme.BentoTextSecondary
import com.example.ui.viewmodel.DiagnosticViewModel

@Composable
fun TcpPingScreen(
    viewModel: DiagnosticViewModel,
    modifier: Modifier = Modifier
) {
    val host by viewModel.pingHost.collectAsState()
    val port by viewModel.pingPort.collectAsState()
    val count by viewModel.pingCount.collectAsState()
    val isPinging by viewModel.isPinging.collectAsState()
    val pingResult by viewModel.pingResult.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Bento Status Banner
        BentoStatusBanner(
            title = if (isPinging) "Testing Socket Handshake..." else "TCP Socket Ping Ready",
            subtitle = "Direct raw network socket RTT measurement",
            statusLabel = if (isPinging) "PINGING" else "READY"
        )

        // Ping Config Bento Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BentoBorder, RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "TARGET SOCKET & PORT",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp,
                    color = BentoTextSecondary
                )
                Text(
                    text = "Network Socket RTT",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = BentoTextPrimary
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = host,
                    onValueChange = { viewModel.setPingHost(it) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Target IP / Host") },
                    placeholder = { Text("e.g. 1.1.1.1 or google.com") },
                    shape = RoundedCornerShape(16.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BentoPrimaryGreen,
                        unfocusedBorderColor = BentoBorder,
                        focusedContainerColor = BentoGreenSageSoft,
                        unfocusedContainerColor = BentoGreenSageSoft
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Port Selection Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Target Port", style = MaterialTheme.typography.bodySmall, color = BentoTextSecondary)
                    Row {
                        listOf(443, 80, 53, 8080, 8443).forEach { p ->
                            FilterChip(
                                selected = port == p,
                                onClick = { viewModel.setPingPort(p) },
                                label = { Text(p.toString(), fontSize = 11.sp) },
                                modifier = Modifier.padding(start = 4.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = BentoGreenSage,
                                    selectedLabelColor = BentoPrimaryGreen
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Packet Count Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Packet Attempts", style = MaterialTheme.typography.bodySmall, color = BentoTextSecondary)
                    Row {
                        listOf(3, 5, 10).forEach { c ->
                            FilterChip(
                                selected = count == c,
                                onClick = { viewModel.setPingCount(c) },
                                label = { Text("$c pkts", fontSize = 11.sp) },
                                modifier = Modifier.padding(start = 4.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = BentoGreenSage,
                                    selectedLabelColor = BentoPrimaryGreen
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { viewModel.runTcpPing() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BentoPrimaryGreen,
                        contentColor = Color.White
                    ),
                    enabled = !isPinging && host.isNotBlank()
                ) {
                    if (isPinging) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = Color.White,
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("MEASURING LATENCY...", fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                    } else {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("TRANSMIT SOCKET PINGS", fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                    }
                }
            }
        }

        // Results Section
        pingResult?.let { res ->
            BentoActiveProcessHero(
                title = "SOCKET HANDSHAKE RESULT",
                mainValue = "${res.avgLatencyMs}",
                subValue = "ms average RTT",
                processNote = "Completed socket handshake with ${res.host}:${res.port} (${res.packetLossPercent}% loss)",
                progress = 1.0f
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BentoBorder, RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${res.host}:${res.port}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = BentoTextPrimary
                            )
                            Text(
                                text = "TCP 3-Way Handshake Breakdown",
                                style = MaterialTheme.typography.bodySmall,
                                color = BentoTextSecondary
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(50),
                            color = if (res.packetLossPercent == 0) BentoGreenSage else BentoAmberContainer
                        ) {
                            Text(
                                text = "${res.packetLossPercent}% Loss",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                color = if (res.packetLossPercent == 0) BentoPrimaryGreen else BentoAmber,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatPill(label = "MIN", value = "${res.minLatencyMs}ms", color = BentoPrimaryGreen, modifier = Modifier.weight(1f))
                        StatPill(label = "AVG", value = "${res.avgLatencyMs}ms", color = BentoCyan, modifier = Modifier.weight(1f))
                        StatPill(label = "MAX", value = "${res.maxLatencyMs}ms", color = BentoAmber, modifier = Modifier.weight(1f))
                        StatPill(label = "RCVD", value = "${res.packetsReceived}/${res.packetsSent}", color = BentoBlue, modifier = Modifier.weight(1f))
                    }

                    if (res.latencies.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "INDIVIDUAL PACKET LATENCIES",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.6.sp,
                            color = BentoTextMuted
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(BentoGreenSageSoft, RoundedCornerShape(14.dp))
                                .padding(12.dp)
                        ) {
                            res.latencies.forEachIndexed { idx, ms ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Packet #${idx + 1}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = BentoTextSecondary
                                    )
                                    Text(
                                        text = "$ms ms",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = if (ms < 100) BentoPrimaryGreen else BentoAmber
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
