package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CountryPreset
import com.example.ui.components.BentoStatusBanner
import com.example.ui.theme.BentoBorder
import com.example.ui.theme.BentoGreenSage
import com.example.ui.theme.BentoGreenSageSoft
import com.example.ui.theme.BentoPrimaryGreen
import com.example.ui.theme.BentoTextMuted
import com.example.ui.theme.BentoTextPrimary
import com.example.ui.theme.BentoTextSecondary
import com.example.ui.viewmodel.DiagnosticViewModel

@Composable
fun WorldwideScreen(
    viewModel: DiagnosticViewModel,
    onNavigateToSingle: (String) -> Unit,
    onNavigateToBatch: () -> Unit,
    modifier: Modifier = Modifier
) {
    val countryPresets = viewModel.countryPresets
    val searchQuery by viewModel.countrySearchQuery.collectAsState()
    var selectedRegion by remember { mutableStateOf("All") }

    val regions = listOf("All", "Global", "Asia", "Europe", "North America", "South America", "Africa", "Middle East", "Oceania")

    val filteredPresets = remember(countryPresets, searchQuery, selectedRegion) {
        countryPresets.filter { preset ->
            val matchesSearch = preset.name.contains(searchQuery, ignoreCase = true) ||
                    preset.code.contains(searchQuery, ignoreCase = true) ||
                    preset.hosts.any { it.contains(searchQuery, ignoreCase = true) }
            val matchesRegion = selectedRegion == "All" || preset.region.equals(selectedRegion, ignoreCase = true)
            matchesSearch && matchesRegion
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Bento Status Banner
        BentoStatusBanner(
            title = "Worldwide DNS & Hosts Directory",
            subtitle = "${countryPresets.size} Country presets • 140+ verified public endpoints",
            statusLabel = "GLOBAL"
        )

        // Search & Filter Bento Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BentoBorder, RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "COUNTRY DIRECTORY",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp,
                    color = BentoTextSecondary
                )
                Text(
                    text = "Browse Global Endpoints",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = BentoTextPrimary
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setCountrySearchQuery(it) },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search country, ISP, or domain...") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = BentoPrimaryGreen)
                    },
                    shape = RoundedCornerShape(16.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BentoPrimaryGreen,
                        unfocusedBorderColor = BentoBorder,
                        focusedContainerColor = BentoGreenSageSoft,
                        unfocusedContainerColor = BentoGreenSageSoft
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Region Chips Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    regions.take(4).forEach { region ->
                        FilterChip(
                            selected = selectedRegion == region,
                            onClick = { selectedRegion = region },
                            label = { Text(region, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BentoGreenSage,
                                selectedLabelColor = BentoPrimaryGreen
                            )
                        )
                    }
                }
            }
        }

        // Countries List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filteredPresets, key = { it.code + it.name }) { preset ->
                CountryPresetCard(
                    preset = preset,
                    onTestHost = { host ->
                        viewModel.runSingleDiagnostic(host)
                        onNavigateToSingle(host)
                    },
                    onScanAll = {
                        viewModel.loadCountryPresetIntoBatch(preset)
                        onNavigateToBatch()
                    }
                )
            }
        }
    }
}

@Composable
fun CountryPresetCard(
    preset: CountryPreset,
    onTestHost: (String) -> Unit,
    onScanAll: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BentoBorder, RoundedCornerShape(20.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(BentoGreenSageSoft),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = preset.flag, fontSize = 22.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = preset.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = BentoTextPrimary
                        )
                        Text(
                            text = "${preset.region} • ${preset.hosts.size} sample hosts",
                            style = MaterialTheme.typography.bodySmall,
                            color = BentoTextSecondary
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = BentoGreenSage,
                    modifier = Modifier.clickable { onScanAll() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Batch Scan",
                            color = BentoPrimaryGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = BentoPrimaryGreen,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sample Host Rows
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                preset.hosts.take(4).forEach { host ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onTestHost(host) }
                            .padding(vertical = 4.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "• $host",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = BentoTextPrimary
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "Test host",
                            tint = BentoTextMuted,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}
