package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bento Grid Design System Colors
val BentoCanvas = Color(0xFFFBFDF8)
val BentoDarkTile = Color(0xFF191C19)
val BentoDarkTileSurface = Color(0xFF232723)

val BentoPrimaryGreen = Color(0xFF386A20)
val BentoPrimaryGreenDark = Color(0xFF2C5419)
val BentoGreenSage = Color(0xFFDDE6D3)
val BentoGreenSageSoft = Color(0xFFF0F5EB)
val BentoGreenAccent = Color(0xFFB1CC9B)
val BentoGreenLight = Color(0xFFE9F2E2)

val BentoBorder = Color(0xFFE1E3DA)
val BentoBorderDark = Color(0xFFC1C9BA)
val BentoBorderDarkTile = Color(0xFF333831)

// Text Colors
val BentoTextPrimary = Color(0xFF191C19)
val BentoTextSecondary = Color(0xFF42493F)
val BentoTextMuted = Color(0xFF72796F)
val BentoTextLight = Color(0xFFFBFDF8)
val BentoTextLightMuted = Color(0xFFBFC9BA)

// Status & Metric Accent Colors
val BentoCyan = Color(0xFF006874)
val BentoBlue = Color(0xFF006495)
val BentoAmber = Color(0xFFB06000)
val BentoAmberContainer = Color(0xFFFFECCF)
val BentoRed = Color(0xFFBA1A1A)
val BentoRedContainer = Color(0xFFFFDAD6)
val BentoGreen = Color(0xFF386A20)
val BentoGreenContainer = Color(0xFFDDE6D3)

// Dark Theme Variants
val BentoCanvasDark = Color(0xFF111411)
val BentoSurfaceDark = Color(0xFF191C19)
val BentoSurfaceVariantDark = Color(0xFF222621)
