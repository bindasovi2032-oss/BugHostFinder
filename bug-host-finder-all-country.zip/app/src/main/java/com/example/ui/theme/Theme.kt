package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = BentoPrimaryGreen,
    onPrimary = Color.White,
    primaryContainer = BentoGreenSage,
    onPrimaryContainer = BentoPrimaryGreenDark,
    secondary = BentoTextSecondary,
    onSecondary = Color.White,
    secondaryContainer = BentoGreenSageSoft,
    onSecondaryContainer = BentoTextPrimary,
    tertiary = BentoCyan,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFCCE8EA),
    onTertiaryContainer = Color(0xFF002024),
    background = BentoCanvas,
    onBackground = BentoTextPrimary,
    surface = Color.White,
    onSurface = BentoTextPrimary,
    surfaceVariant = BentoGreenSageSoft,
    onSurfaceVariant = BentoTextSecondary,
    outline = BentoBorder,
    outlineVariant = BentoBorderDark,
    error = BentoRed,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = BentoGreenAccent,
    onPrimary = BentoPrimaryGreenDark,
    primaryContainer = BentoPrimaryGreen,
    onPrimaryContainer = BentoGreenSage,
    secondary = BentoGreenSage,
    onSecondary = BentoTextPrimary,
    secondaryContainer = BentoSurfaceVariantDark,
    onSecondaryContainer = BentoGreenSageSoft,
    tertiary = Color(0xFF88D2DC),
    onTertiary = Color(0xFF00363D),
    background = BentoCanvasDark,
    onBackground = BentoTextLight,
    surface = BentoSurfaceDark,
    onSurface = BentoTextLight,
    surfaceVariant = BentoSurfaceVariantDark,
    onSurfaceVariant = BentoTextLightMuted,
    outline = BentoBorderDarkTile,
    outlineVariant = Color(0xFF42493F),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false, // Default to the Bento Grid signature clean aesthetic
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = colorScheme.background.toArgb()
                window.navigationBarColor = colorScheme.surfaceVariant.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
