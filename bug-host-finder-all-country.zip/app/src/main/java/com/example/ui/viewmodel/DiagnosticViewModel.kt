package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BatchHostItem
import com.example.data.BatchScanStatus
import com.example.data.CountryCatalog
import com.example.data.CountryPreset
import com.example.data.DiagnosticEngine
import com.example.data.HostDiagnosticResult
import com.example.data.TcpPingResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONArray
import org.json.JSONObject

class DiagnosticViewModel(application: Application) : AndroidViewModel(application) {

    private val engine = DiagnosticEngine()
    private val prefs = application.getSharedPreferences("bug_host_finder_prefs", Context.MODE_PRIVATE)

    // Single Diagnostic State
    private val _singleHostInput = MutableStateFlow("cloudflare.com")
    val singleHostInput: StateFlow<String> = _singleHostInput.asStateFlow()

    private val _selectedPort = MutableStateFlow(443)
    val selectedPort: StateFlow<Int> = _selectedPort.asStateFlow()

    private val _selectedMethod = MutableStateFlow("GET")
    val selectedMethod: StateFlow<String> = _selectedMethod.asStateFlow()

    private val _followRedirects = MutableStateFlow(true)
    val followRedirects: StateFlow<Boolean> = _followRedirects.asStateFlow()

    private val _isDiagnosing = MutableStateFlow(false)
    val isDiagnosing: StateFlow<Boolean> = _isDiagnosing.asStateFlow()

    private val _diagnosticResult = MutableStateFlow<HostDiagnosticResult?>(null)
    val diagnosticResult: StateFlow<HostDiagnosticResult?> = _diagnosticResult.asStateFlow()

    // Batch Scanner State
    private val _batchText = MutableStateFlow("cloudflare.com\ngoogle.com\nfastly.com\napple.com\nnetflix.com")
    val batchText: StateFlow<String> = _batchText.asStateFlow()

    private val _batchItems = MutableStateFlow<List<BatchHostItem>>(emptyList())
    val batchItems: StateFlow<List<BatchHostItem>> = _batchItems.asStateFlow()

    private val _isBatchScanning = MutableStateFlow(false)
    val isBatchScanning: StateFlow<Boolean> = _isBatchScanning.asStateFlow()

    private val _batchProgress = MutableStateFlow(0f)
    val batchProgress: StateFlow<Float> = _batchProgress.asStateFlow()

    private var batchJob: Job? = null

    // TCP Ping Dedicated Tool
    private val _pingHost = MutableStateFlow("1.1.1.1")
    val pingHost: StateFlow<String> = _pingHost.asStateFlow()

    private val _pingPort = MutableStateFlow(443)
    val pingPort: StateFlow<Int> = _pingPort.asStateFlow()

    private val _pingCount = MutableStateFlow(4)
    val pingCount: StateFlow<Int> = _pingCount.asStateFlow()

    private val _isPinging = MutableStateFlow(false)
    val isPinging: StateFlow<Boolean> = _isPinging.asStateFlow()

    private val _pingResult = MutableStateFlow<TcpPingResult?>(null)
    val pingResult: StateFlow<TcpPingResult?> = _pingResult.asStateFlow()

    // Worldwide Catalog
    val countryPresets: List<CountryPreset> = CountryCatalog.presets

    private val _selectedCountry = MutableStateFlow(CountryCatalog.presets.first())
    val selectedCountry: StateFlow<CountryPreset> = _selectedCountry.asStateFlow()

    private val _countrySearchQuery = MutableStateFlow("")
    val countrySearchQuery: StateFlow<String> = _countrySearchQuery.asStateFlow()

    // History
    private val _historyList = MutableStateFlow<List<HostDiagnosticResult>>(emptyList())
    val historyList: StateFlow<List<HostDiagnosticResult>> = _historyList.asStateFlow()

    init {
        loadHistory()
        // Run an initial quick test on cloudflare.com so the screen is immediately populated with real data
        runSingleDiagnostic("cloudflare.com", 443, "GET", true)
    }

    fun setSingleHostInput(host: String) {
        _singleHostInput.value = host
    }

    fun setSelectedPort(port: Int) {
        _selectedPort.value = port
    }

    fun setSelectedMethod(method: String) {
        _selectedMethod.value = method
    }

    fun setFollowRedirects(follow: Boolean) {
        _followRedirects.value = follow
    }

    fun runSingleDiagnostic(
        host: String = _singleHostInput.value,
        port: Int = _selectedPort.value,
        method: String = _selectedMethod.value,
        follow: Boolean = _followRedirects.value
    ) {
        if (host.isBlank() || _isDiagnosing.value) return
        _isDiagnosing.value = true
        _singleHostInput.value = host
        _selectedPort.value = port
        _selectedMethod.value = method
        _followRedirects.value = follow

        viewModelScope.launch {
            val result = engine.diagnoseHost(
                rawInput = host,
                port = port,
                method = method,
                followRedirects = follow
            )
            _diagnosticResult.value = result
            _isDiagnosing.value = false
            saveToHistory(result)
        }
    }

    fun setBatchText(text: String) {
        _batchText.value = text
    }

    fun loadCountryPresetIntoBatch(preset: CountryPreset) {
        _selectedCountry.value = preset
        _batchText.value = preset.hosts.joinToString("\n")
    }

    fun startBatchScan() {
        if (_isBatchScanning.value) return
        val lines = _batchText.value.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()

        if (lines.isEmpty()) return

        val items = lines.map { BatchHostItem(host = it, status = BatchScanStatus.IDLE) }
        _batchItems.value = items
        _isBatchScanning.value = true
        _batchProgress.value = 0f

        batchJob = viewModelScope.launch(Dispatchers.IO) {
            val semaphore = Semaphore(4) // 4 concurrent scans
            var completedCount = 0

            items.forEachIndexed { index, item ->
                launch {
                    semaphore.withPermit {
                        // Mark as scanning
                        updateBatchItem(item.id) { it.copy(status = BatchScanStatus.SCANNING) }

                        val res = engine.diagnoseHost(
                            rawInput = item.host,
                            port = 443,
                            method = "HEAD",
                            followRedirects = true
                        )

                        updateBatchItem(item.id) {
                            it.copy(
                                status = if (res.isSuccess) BatchScanStatus.SUCCESS else BatchScanStatus.FAILED,
                                statusCode = res.httpStatusCode,
                                latencyMs = res.responseTimeMs,
                                server = res.serverHeader,
                                cdn = res.cdnDetected,
                                resolvedIp = res.ipAddresses.firstOrNull(),
                                error = res.errorDetail
                            )
                        }

                        completedCount++
                        _batchProgress.value = completedCount.toFloat() / items.size
                    }
                }
            }
            // Wait for completion or cancellation
            _isBatchScanning.value = false
        }
    }

    fun stopBatchScan() {
        batchJob?.cancel()
        _isBatchScanning.value = false
        _batchItems.value = _batchItems.value.map {
            if (it.status == BatchScanStatus.SCANNING) it.copy(status = BatchScanStatus.IDLE) else it
        }
    }

    private fun updateBatchItem(id: String, transform: (BatchHostItem) -> BatchHostItem) {
        _batchItems.value = _batchItems.value.map {
            if (it.id == id) transform(it) else it
        }
    }

    // Ping actions
    fun setPingHost(host: String) {
        _pingHost.value = host
    }

    fun setPingPort(port: Int) {
        _pingPort.value = port
    }

    fun setPingCount(count: Int) {
        _pingCount.value = count
    }

    fun runTcpPing() {
        if (_isPinging.value || _pingHost.value.isBlank()) return
        _isPinging.value = true
        val host = engine.sanitizeHost(_pingHost.value)
        val port = _pingPort.value
        val count = _pingCount.value

        viewModelScope.launch {
            val result = engine.pingTcpSocket(host, port, attempts = count)
            _pingResult.value = result
            _isPinging.value = false
        }
    }

    fun setCountrySearchQuery(query: String) {
        _countrySearchQuery.value = query
    }

    fun selectCountry(preset: CountryPreset) {
        _selectedCountry.value = preset
    }

    // History Persistence
    private fun saveToHistory(result: HostDiagnosticResult) {
        val current = _historyList.value.toMutableList()
        current.removeAll { it.host.equals(result.host, ignoreCase = true) }
        current.add(0, result)
        if (current.size > 25) {
            current.removeAt(current.lastIndex)
        }
        _historyList.value = current
        persistHistoryJson(current)
    }

    fun clearHistory() {
        _historyList.value = emptyList()
        prefs.edit().remove("history_json").apply()
    }

    private fun persistHistoryJson(list: List<HostDiagnosticResult>) {
        try {
            val array = JSONArray()
            list.forEach { item ->
                val obj = JSONObject()
                obj.put("host", item.host)
                obj.put("port", item.port)
                obj.put("isSuccess", item.isSuccess)
                obj.put("statusCode", item.httpStatusCode ?: 0)
                obj.put("statusMsg", item.httpStatusMessage ?: "")
                obj.put("latency", item.responseTimeMs)
                obj.put("cdn", item.cdnDetected ?: "")
                obj.put("server", item.serverHeader ?: "")
                obj.put("ip", item.ipAddresses.firstOrNull() ?: "")
                obj.put("country", item.geoInfo?.country ?: "")
                obj.put("flag", item.geoInfo?.flagEmoji ?: "")
                obj.put("timestamp", item.timestamp)
                array.put(obj)
            }
            prefs.edit().putString("history_json", array.toString()).apply()
        } catch (_: Exception) {}
    }

    private fun loadHistory() {
        try {
            val str = prefs.getString("history_json", null) ?: return
            val array = JSONArray(str)
            val list = mutableListOf<HostDiagnosticResult>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val code = obj.optInt("statusCode", 0)
                val ip = obj.optString("ip", "")
                list.add(
                    HostDiagnosticResult(
                        host = obj.getString("host"),
                        targetUrl = "https://${obj.getString("host")}/",
                        port = obj.optInt("port", 443),
                        isSuccess = obj.optBoolean("isSuccess", true),
                        httpStatusCode = if (code != 0) code else null,
                        httpStatusMessage = obj.optString("statusMsg", "OK"),
                        responseTimeMs = obj.optLong("latency", 0),
                        cdnDetected = obj.optString("cdn", "").ifEmpty { null },
                        serverHeader = obj.optString("server", "").ifEmpty { null },
                        ipAddresses = if (ip.isNotEmpty()) listOf(ip) else emptyList(),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }
            _historyList.value = list
        } catch (_: Exception) {}
    }

    fun shareDiagnosticReport(context: Context, result: HostDiagnosticResult) {
        val sb = StringBuilder()
        sb.append("=== Bug Host Finder Diagnostic Report ===\n")
        sb.append("Target Host: ${result.host}\n")
        sb.append("Target URL: ${result.targetUrl}\n")
        sb.append("Port: ${result.port} | Protocol: ${result.protocol ?: "HTTP/HTTPS"}\n")
        sb.append("HTTP Status: ${result.httpStatusCode ?: "N/A"} ${result.httpStatusMessage ?: ""}\n")
        sb.append("Response Time: ${result.responseTimeMs} ms\n")
        sb.append("Server Header: ${result.serverHeader ?: "Hidden/None"}\n")
        sb.append("CDN/Edge: ${result.cdnDetected ?: "Direct Origin"}\n")
        sb.append("Resolved IPs: ${result.ipAddresses.joinToString(", ")}\n")
        if (!result.reverseDns.isNullOrBlank()) {
            sb.append("Reverse DNS: ${result.reverseDns}\n")
        }
        result.geoInfo?.let { geo ->
            sb.append("Location: ${geo.country} (${geo.city}) | Flag: ${geo.flagEmoji}\n")
            sb.append("ISP: ${geo.isp} | ASN: ${geo.asNumber}\n")
        }
        result.sslInfo?.let { ssl ->
            sb.append("\n[SSL/TLS Certificate]\n")
            sb.append("Common Name: ${ssl.subjectCn}\n")
            sb.append("Issuer: ${ssl.issuerCn}\n")
            sb.append("Valid To: ${ssl.validTo} (${ssl.daysRemaining} days left)\n")
            sb.append("Protocol: ${ssl.protocol} | Cipher: ${ssl.cipherSuite}\n")
        }
        if (result.headers.isNotEmpty()) {
            sb.append("\n[Response Headers]\n")
            result.headers.forEach { (k, v) ->
                sb.append("$k: $v\n")
            }
        }
        sb.append("\nGenerated by Bug Host Finder All Country")

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Diagnostic Report for ${result.host}")
            putExtra(Intent.EXTRA_TEXT, sb.toString())
        }
        context.startActivity(Intent.createChooser(intent, "Share Diagnostic Report"))
    }
}
